package GameObject;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

import MainFrame.GameBoard;
import MonsterStuff.Monster;

/**
 * This class handles all the bullet and bubbles creation. 
 * Bubbles and bullet and are things shot by the characters. 
 * @author harmetsm, koenignm, ravellp
 *
 */
public abstract class Ammo extends GameObject {

	public GameObject character;
	protected double xVelocity, yVelocity;
	public int ammoRadius;
	private boolean left;
	
	/**
	 * Class for Ammo types : Bullets and Bubbles
	 * 
	 */
	public Ammo(Character shooter, int radius, double dx, double dy) {
		super();
		
		this.xVelocity = dx;
		this.yVelocity = dy;
				
		character = shooter;
		left = shooter.getLeft();
		this.ammoRadius = radius; 
		super.setCoord(character.getXCoord(), character.getYCoord());
	}
	
	public void update() {
		if(left) {
			xCoord -= xVelocity;
		}
		else {
			xCoord += xVelocity;
		}
	}

	public void drawOn(Graphics2D g) {
		BufferedImage object = null;
		try {
			object = ImageIO.read(new File("photos/" + this.getClass().getSimpleName() + ".png"));

		} catch (IOException e) {
			System.out.println("Image not found");
		}

		g.drawImage(object, null, xCoord - 20, yCoord - 30);

	}
	
	public Shape getShape() {
		return new Ellipse2D.Double(xCoord, yCoord, ammoRadius, ammoRadius);
	}

	public void collidesWith(Block b) {
		if ( this.overlapsBlock(b) || this.xCoord > 1000) {
			this.markToRemove();
		}
	}
}
