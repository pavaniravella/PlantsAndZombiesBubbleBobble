package GameObject;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;

import MainFrame.GameBoard;

/**
 * This class designs the borders and obstacles in the game. 
 * The block class creates the layout of each level. 
 * @author harmetsm, koenignm, ravellp
 *
 */
public class Block {
	
	public final static int BLOCK_SIZE = 50;
	public int xPos, yPos;
	
	public Block(int x, int y) {
		this.xPos = x;
		this.yPos = y;
		
	}
	
	public void drawOn(Graphics2D g) {
		g.setColor(Color.BLACK);
		Rectangle rect = new Rectangle(this.xPos, this.yPos, BLOCK_SIZE, BLOCK_SIZE);
		g.fill(rect);

	}
	
	public boolean isTopRow() {
		return (yPos == 0);
	}
	
	public int getX() {
		return xPos;
	}
	
	public int getY() {
		return yPos;
	}
	
	public Rectangle2D.Double getShape(){
		Rectangle2D.Double temp = new Rectangle2D.Double(xPos, yPos, BLOCK_SIZE, BLOCK_SIZE);
		return temp;
	}
}
