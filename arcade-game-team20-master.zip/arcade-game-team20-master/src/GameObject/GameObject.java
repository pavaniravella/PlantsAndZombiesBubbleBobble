package GameObject;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import HeroClasses.Bubble;
import HeroClasses.Hero;
import MainFrame.GameBoard;
import MonsterStuff.Bullet;
import MonsterStuff.Monster;

/**
 * This class is the super class of all objects in the gameboard. It is a common
 * class that implements an interface because this allows access to all objects
 * and check for collisions.
 * 
 * @author harmetsm, koenignm, ravellp
 *
 */
public abstract class GameObject {

	public int xCoord, yCoord;
	public double xVelocity, yVelocity;
	protected final int RADIUS = 20;
	protected GameBoard board;
	protected boolean shouldRemove;

	public GameObject() {
		board = GameBoard.getBoard();
	}

	public int getXCoord() {
		return xCoord;
	}

	public int getYCoord() {
		return yCoord;
	}

	public void setCoord(int x, int y) {
		this.xCoord = x;
		this.yCoord = y;
	}

	public abstract void drawOn(Graphics2D g2);

	public abstract void update();

	/**
	 * Necessary method so that we can implement a "markToRemove()" method
	 * 
	 * @return boolean
	 */
	public boolean shouldRemove() {
		return this.shouldRemove;
	}

	public void markToRemove() {
		this.shouldRemove = true;
	}

	public void onRemove() {
		// do nothing for now
	}

	public abstract Shape getShape();

	public abstract void collidesWith(GameObject g);

	public abstract void collidesWith(Block b);

	public abstract void collidesWith(Monster m);

	public abstract void collidesWith(Bubble b);

	public abstract void collidesWith(Bullet b);

	public abstract void collidesWith(Hero h);

	public boolean overlaps(GameObject other) {
		return this.getShape().intersects(other.getShape().getBounds2D());
	}

	public boolean overlapsBlock(Block block) {
		return this.getShape().intersects(block.getShape().getBounds2D());
	}
}
