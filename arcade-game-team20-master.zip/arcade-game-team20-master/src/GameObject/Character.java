package GameObject;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import HeroClasses.Bubble;
import MainFrame.GameBoard;
import MonsterStuff.Monster;

/**
 * 	This class is the superclass of the Monster, Shooting Monster, and Hero class. 
 * The character class handles the movement, drawing, and collisions for the characters in the class. 
 * 
 * @author harmetsm, koenignm, ravellp
 *
 */
public abstract class Character extends GameObject{
	private ArrayList<Monster> monsters;
	private ArrayList<Block> blocks;

	private String name;
	protected boolean left;
	protected boolean isJumping;

	/**
	 * TODO document method
	 */
	public Character(String name, int x, int y, double dx, double dy) {
		super();
		this.name = name;
		this.xCoord = x;
		this.yCoord = y;

		isJumping = true;

		xVelocity = dx;
		yVelocity = dy;

		monsters = board.getMonsters();
		blocks = board.getBlocks();
	}

	public void update() {
		if (!this.shouldRemove) {
			xCoord += xVelocity;
			yCoord += yVelocity;
			yVelocity += .05;
		}
	}

	public void collideWith(Block b) {
		if (xCoord <= Block.BLOCK_SIZE + 2) {
			xCoord = Block.BLOCK_SIZE + 4;
		}
		
		else if ( xCoord >= (Block.BLOCK_SIZE * 18) + 27) {
			xCoord = (Block.BLOCK_SIZE * 18) + 27;
		}
		
		if (this.overlapsBlock(b)) {

			
			// checking if block is to left
			if (xCoord >= b.getX() + Block.BLOCK_SIZE) {
				xCoord = b.getX() - Block.BLOCK_SIZE;
				collideWith(b);
			}

			// checking if block is to the right
			if (xCoord + RADIUS == b.getX()) {
				xCoord = b.getX() - RADIUS;
			}

			// checking if block is below
			else if (yCoord + RADIUS > b.getY()) {		
				yCoord = b.getY() - RADIUS;
				yVelocity = 0;
				isJumping = false;
			}

			// checking for if block is at top
			if (yCoord <= Block.BLOCK_SIZE) {
				yCoord = b.getY() + Block.BLOCK_SIZE + 1;
				isJumping = true;
			}			
		}
	}
	
	public String collidingOnSides() {
		if (xCoord <= Block.BLOCK_SIZE + 9) {
			return "left";
		}
		if (xCoord >= (Block.BLOCK_SIZE * 18) + 20) {
			return "right";
		}
		return "";
	}

	public void setAsJumping() {
		isJumping = true;
	}
	
	public boolean isJumping() {
		return isJumping;
	}

	public Rectangle2D.Double getShape() {
		return (new Rectangle2D.Double(xCoord, yCoord, RADIUS, RADIUS));
	}

	public boolean getLeft() {
		return (xVelocity >= 0) ? false : true;
	}

	public void drawOn(Graphics2D g2) {
		BufferedImage object = null;
		try {
			if (getLeft()){
				object = ImageIO.read(new File("photos/" + this.getClass().getSimpleName()+ ".png"));
			}
			else {
				object = ImageIO.read(new File("photos/" + this.getClass().getSimpleName()+ "Right.png"));
			}
		} catch (IOException e) {

			System.out.println("Image not found Character");
		}
		if (this.getClass().getSimpleName().equals("Monster") || this.getClass().getSimpleName().equals("ShootingMonster")) {
			g2.drawImage(object, null, xCoord - 9, yCoord - 30);
		}
		else {
			g2.drawImage(object, null, xCoord - 9, yCoord - 20);
		}
	
	}

	public void shoot() {
	}



}
