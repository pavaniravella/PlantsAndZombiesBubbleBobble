package GameObject;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JLabel;

import com.sun.glass.events.KeyEvent;

import HeroClasses.Hero;
import MainFrame.GameBoard;
import MainFrame.LevelIO;

/**
 * This class updates the gameboard, keeps track of the score, and makes a timer
 * that allows for the images to be rendered.
 * 
 * @author harmetsm, koenignm, ravellp
 *
 */
public class GameListener implements ActionListener {

	private GameBoard game;
	private JLabel score, lives;
	private LevelIO levelIO;

	/**
	 * 
	 */
	public GameListener(GameBoard board, JLabel givenScore, JLabel givenLives, LevelIO levelRunner) {
		this.game = board;
		this.score = givenScore;
		this.lives = givenLives;
		this.levelIO = levelRunner;
	}

	public void advanceOneTick() {
		this.game.updateState();
	}

	public void updateDisplay() {
		score.setText("Score : " + game.getHero().getScore());
		lives.setText("Lives : " + (3 - game.getHero().getNumOfDeaths()));
		if (GameBoard.getBoard().getMonsters().size() == 0) {
			levelIO.changeLevel(KeyEvent.VK_U);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		updateDisplay();
		advanceOneTick();

	}

}
