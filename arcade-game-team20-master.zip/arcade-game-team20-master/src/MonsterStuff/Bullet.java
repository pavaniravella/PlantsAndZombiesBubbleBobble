package MonsterStuff;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import GameObject.Ammo;
import GameObject.Block;
import GameObject.Character;
import GameObject.GameObject;
import HeroClasses.Bubble;
import HeroClasses.Hero;
import MainFrame.GameBoard;

/**
 * This class is responsible for the drawing and movement of bullets coming out
 * of Shooting Monsters.
 * 
 */
public class Bullet extends Ammo {

	private Character shooter;

	public Bullet(Character shooter) {
		super(shooter, 20, 1, 0);
		this.shooter = shooter;
		// arbitary value
	}

	@Override
	public void drawOn(Graphics2D g) {
		Graphics2D g2 = (Graphics2D) g;
		BufferedImage object = null;
		try {
			if (shooter.getLeft()) {
				object = ImageIO.read(new File("photos/Bullet.png"));
			} else {
				object = ImageIO.read(new File("photos/BulletRight.png"));
			}

		} catch (IOException e) {
			System.out.println("Image not found");
		}

		g2.drawImage(object, null, xCoord - 20, yCoord - 30);
	}

	@Override
	public boolean shouldRemove() {
		return shouldRemove;
	}

	@Override
	public void collidesWith(GameObject g) {
		g.collidesWith(this);
	}

	@Override
	public void collidesWith(Block b) {
		super.collidesWith(b);
	}

	@Override
	public void collidesWith(Monster m) {
		// do nothing
	}

	@Override
	public void collidesWith(Bubble b) {
		// do nothing
	}

	@Override
	public void collidesWith(Bullet b) {
		// do nothing
	}

	@Override
	public void collidesWith(Hero h) {
		if (this.overlaps(h)) {
			h.restartHero(500, 70);
			System.out.println("Hero shot!");
		}
	}
}
