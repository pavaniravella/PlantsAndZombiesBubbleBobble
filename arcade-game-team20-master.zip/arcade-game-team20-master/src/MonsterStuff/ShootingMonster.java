package MonsterStuff;

import java.util.ArrayList;

import MainFrame.GameBoard;

/**
 * This class handles action of making the monster objects shoot bullets.
 *
 */
public class ShootingMonster extends Monster {

	/**
	 * 
	 */
	public ShootingMonster(String givenName, int x, int y, double dx, double dy) {
		super(givenName, x, y, dx, dy);
	}

	@Override
	public void shoot() {
		GameBoard.getBoard().addAmmo(new Bullet(this));

	}
}
