package MonsterStuff;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.sun.javafx.scene.traversal.Direction;

import GameObject.Block;
import GameObject.Character;
import GameObject.GameObject;
import HeroClasses.Bubble;
import HeroClasses.Fruit;
import HeroClasses.Hero;
import MainFrame.GameBoard;

/**
 * This class is responsible for the drawing and the movement of the monster. It
 * handles the collisions for blocks and the reversing of moment when it hits a
 * block.
 */
public class Monster extends Character {

	private boolean inBubble;

	/**
	 * @param
	 * @param name
	 * @param x
	 * @param y
	 * @param givenBoard
	 */

	public Monster(String givenName, int x, int y, double dx, double dy) {
		super(givenName, x, y, dx, dy);
		inBubble = false;
	}

	// hero tracking movement
	/*
	 * if (hero.getXCoord() < xCoord) { if (!this.isColliding("left", -2, 0)) {
	 * xCoord -= 2; } } if (hero.getXCoord() > this.xCoord) { if
	 * (!this.isColliding("right", 2, 0)) { xCoord += 2; }
	 * 
	 * } if (hero.getYCoord() < this.yCoord) { if (!this.isColliding("down", 0, 2))
	 * { yCoord += 2; }
	 * 
	 * } if (hero.getYCoord() > this.yCoord) { if (!this.isColliding("up", 0, -20))
	 * { yCoord -= 20; }
	 * 
	 * }
	 */

	public void drawOn(Graphics2D g2) {
		super.drawOn(g2);
	}

	public void reverseDirection() {
		this.xVelocity = -this.xVelocity;
	}

	@Override
	public void collidesWith(Block b) {
		if (inBubble) {
			if (yCoord <= Block.BLOCK_SIZE) {
				yCoord = b.getY() + Block.BLOCK_SIZE + 1;
				inBubble = false;
				yVelocity = -1;
				xVelocity = -1;
			}
		} else {
			super.collideWith(b);
			if (this.collidingOnSides().equals("left")) {
				xCoord += 1;
				xVelocity = -xVelocity;
			} else if (this.collidingOnSides().equals("right")) {
				xCoord -= 3;
				xVelocity = -xVelocity;
			}

		}

	}

	public boolean shouldRemove() {
		return this.shouldRemove;
	}

	@Override
	public void update() {
		if (!this.shouldRemove) {
			xCoord += xVelocity;
			yCoord += yVelocity;
			yVelocity += .03;
		}
	}

	@Override
	public void collidesWith(Monster m) {
		// do nothing
	}

	@Override
	public void collidesWith(Bubble b) {
		if (this.overlaps(b)) {
			this.yVelocity = -1;
			this.xVelocity = 0;
			b.yCoord = this.yCoord - 8;
			inBubble = true;
			b.collidesWith(this);
		}

	}

	public boolean getInBubble() {
		return this.inBubble;
	}

	@Override
	public void collidesWith(Bullet b) {
		// do nothing
	}

	@Override
	public void collidesWith(Hero h) {
		if (this.overlaps(h)) {
			if (inBubble) {
				Fruit temp = new Fruit(h, 0.0, 1.0);
				GameBoard.getBoard().markToAddFruit(temp);
				markToRemove();
			}
		}
	}

	@Override
	public void collidesWith(GameObject g) {
		g.collidesWith(this);
	}

}
