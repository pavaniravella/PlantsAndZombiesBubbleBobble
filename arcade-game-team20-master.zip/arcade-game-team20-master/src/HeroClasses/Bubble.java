package HeroClasses;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import GameObject.Ammo;
import GameObject.Block;
import GameObject.Character;
import GameObject.GameObject;
import MainFrame.GameBoard;
import MonsterStuff.Bullet;
import MonsterStuff.Monster;

/**
 * 
 * The bubble class handles the drawing and movement of bubbles shot from the
 * hero. The class takes care of the rendering and checking for collisions with
 * monsters.
 *
 */
public class Bubble extends Ammo {

	public static final int BUBBLE_RADIUS = 40;
	private boolean containsMonster;
	private Color color;

	public Bubble(Character shooter) {
		super(shooter, BUBBLE_RADIUS, 1, 0);
		containsMonster = false;
		color = Color.CYAN;
	}

	@Override
	public boolean shouldRemove() {
		return shouldRemove;
	}

	@Override
	public void collidesWith(GameObject g) {
		g.collidesWith(this);
	}

	@Override
	public void collidesWith(Block b) {
		if (yCoord <= Block.BLOCK_SIZE) {
			this.markToRemove();
		}

	}

	@Override
	public void collidesWith(Monster m) {
		if (this.overlaps(m)) {
			this.yVelocity = -1;
			this.xVelocity = 0;
			xCoord = m.xCoord - 8;
			containsMonster = true;
//			m.yCoord = yCoord;
		}
	}

	@Override
	public void collidesWith(Bubble b) {
	}

	@Override
	public void collidesWith(Bullet b) {
		if (this.overlaps(b)) {
			markToRemove();
		}
	}

	@Override
	public void collidesWith(Hero h) {
		if (containsMonster && this.overlaps(h)) {
			markToRemove();
		}
	}

	public void drawOn(Graphics2D g) {
		super.drawOn(g);
	}

}
