package HeroClasses;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import GameObject.Block;
import GameObject.Character;
import GameObject.GameObject;
import MainFrame.GameBoard;
import MonsterStuff.Bullet;
import MonsterStuff.Monster;

/**
 * 
 * This class draws the hero, moves the hero, and checks if it collides with
 * blocks, monsters, and bullets.
 * 
 * 
 * 
 * @param name
 * @param x
 * @param y
 */

public class Hero extends Character {

	private int numOfDeaths;
	private int score;

	public Hero(String name, int x, int y, double dx, double dy) {
		super(name, x, y, dx, dy);
		score = 0;
	}

	public int getScore() {
		return this.score;
	}

	public void addToScore(int toAdd) {
		this.score += toAdd;
	}

	public int getNumOfDeaths() {
		return this.numOfDeaths;
	}

	public boolean monsterAttacking(Monster monster) {
		Rectangle2D.Double b = monster.getShape();
		return b.intersects(xCoord, yCoord, RADIUS, RADIUS);
	}

	public void restartHero(int posX, int posY) {
		if (this.numOfDeaths < 2) {
			this.xCoord = posX;
			this.yCoord = posY;
		} else {
			// TODO make into a closing screen
			System.exit(0);
		}
	}

	@Override
	public void onRemove() {

	}

	public void drawOn(Graphics2D g2) {
		if (score > 30) {
			BufferedImage object = null;
			try {
				if (getLeft()){
					object = ImageIO.read(new File("photos/powerUp.png"));
				}
				else {
					object = ImageIO.read(new File("photos/powerUpRight.png"));
				}
			} catch (IOException e) {

				System.out.println("Image not found Character");
			}
				g2.drawImage(object, null, xCoord - 9, yCoord - 20);
		
		}
		else{
			super.drawOn(g2);
		}
	}

	public void colorFlash() {
		if (this.shouldRemove) {
			// TODO finish Implementing
		}
	}

	public void shoot() {
		Bubble temp = new Bubble(this);
		GameBoard.getBoard().addAmmo(temp);
	}

	@Override
	public void collidesWith(Block b) {
		super.collideWith(b);
	}

	@Override
	public void collidesWith(Monster m) {
		if (this.overlaps(m) && !m.getInBubble()) {
			if (numOfDeaths < 3) {
				restartHero(500, 70);
				numOfDeaths++;
			} else {
//				System.exit(0);
			}
			// TODO make it go to a home page

			m.collidesWith(this);
		} else if (this.overlaps(m) && m.getInBubble()) {
			m.collidesWith(this);
		}
	}

	@Override
	public void collidesWith(Bubble b) {
		// does nothing
	}

	@Override
	public void collidesWith(Bullet b) {
		if (this.overlaps(b)) {
			this.numOfDeaths++;
			restartHero(500, 70);
		}
	}

	@Override
	public void collidesWith(Hero h) {
		// do nothing
	}

	@Override
	public void collidesWith(GameObject g) {
		g.collidesWith(this);
	}

	public void collidesWith(Fruit f) {
		if (this.overlaps(f)) {
			this.score += 5;
			// TODO Make a JLabel Show up in the middle of the screen that says Power UP!
			this.xVelocity += 0.5;
			this.yVelocity += 0.5;
		}
	}

}
