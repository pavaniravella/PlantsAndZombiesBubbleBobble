package HeroClasses;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import GameObject.Ammo;
import GameObject.Block;
import GameObject.Character;
import GameObject.GameObject;
import MainFrame.GameBoard;
import MonsterStuff.Bullet;
import MonsterStuff.Monster;

/**
 * This class makes an apple appear on the screen. It makes sure that the hero
 * can pick up the apple and gain points.
 *
 * 
 * 
 */
public class Fruit extends Ammo {

	private boolean isGrounded;
	private final static int FRUIT_RADIUS = 15;

	public Fruit(Hero shooter, double dx, double dy) {
		super(shooter, FRUIT_RADIUS, dx, dy);
		xCoord = shooter.getXCoord();
		yCoord = shooter.getYCoord() + 20;
		isGrounded = false;
	}

	public void drawOn(Graphics2D g2) {
		super.drawOn(g2);
	}

	public void update() {
		xCoord += xVelocity;
		yCoord += yVelocity;
	}

	@Override
	public void collidesWith(GameObject g) {
		// do nothing since we only care about it's collision with hero
	}

	@Override
	public void collidesWith(Block b) {
		if (this.overlapsBlock(b) && yCoord + FRUIT_RADIUS > b.getY()) {
			yCoord = b.getY() - RADIUS;
			yVelocity = 0;
			isGrounded = true;
		}
		/*
		 * if(yCoord + FRUIT_RADIUS >= b.getY()) { yCoord = b.getY() - FRUIT_RADIUS; }
		 */
	}

	@Override
	public void collidesWith(Monster m) {
		// do nothing
	}

	@Override
	public void collidesWith(Bubble b) {

		// do nothing
	}

	@Override
	public void collidesWith(Bullet b) {

		// do nothing
	}

	@Override
	public void collidesWith(Hero h) {
		if (this.overlaps(h)) {
			markToRemove();
			h.collidesWith(this);
		}
	}

}
