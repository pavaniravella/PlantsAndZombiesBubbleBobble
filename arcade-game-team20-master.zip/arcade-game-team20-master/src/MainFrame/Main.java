package MainFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.sun.prism.Image;

import GameObject.GameListener;

public class Main {

	/**
	 * Starts the ball rolling and creates the frame, listeners, and levelRunner.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		startMenu();
	}
	
	public static void startMenu() {
		JFrame firstFrame = new JFrame("Bubble Bobble");
		firstFrame.setSize(800, 600);
		JPanel panel = new JPanel();

		ImageIcon image = new ImageIcon("photos\\bubbleBobble.png");
		JLabel label = new JLabel(image);
		
		JButton startGame = new JButton("Play Game");
		startGame.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				runMain();
			}
			
		});
		
		panel.add(startGame, BorderLayout.SOUTH);		
		
		panel.add(label);

		firstFrame.add(panel);

		firstFrame.setVisible(true);
		firstFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	public static void runMain() {
		GameBoard game = GameBoard.getBoard();
		JFrame frame = game.getFrame();
		frame.setSize(1000, 800);

		BufferedImage bub = null;

		try {
			bub = ImageIO.read(new File("photos/Hero.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		frame.setIconImage(bub);
		frame.setTitle("Bubble Bobble");

		JPanel panel = new JPanel();
		frame.add(panel, BorderLayout.NORTH);
		frame.add(game, BorderLayout.CENTER);

		String level = JOptionPane.showInputDialog(frame, "Which level would you like");

		LevelIO levelRunner = new LevelIO(Integer.parseInt(level));

		KeyListener listener = new ArcadeListener(game, levelRunner);
		frame.addKeyListener(listener);

		JLabel scoreCounter = new JLabel("Score : " + game.getHero().getScore());
		JLabel deathLabel = new JLabel("Deaths : " + game.getHero().getNumOfDeaths());

		GameListener listen = new GameListener(game, scoreCounter, deathLabel, levelRunner);

		// panel configurations
		panel.add(scoreCounter, BorderLayout.LINE_START);
		panel.add(deathLabel, BorderLayout.LINE_END);
		panel.setBackground(Color.red);
		panel.setForeground(Color.WHITE);
		panel.setFont(Font.getFont(Font.SANS_SERIF));

//		if (game.getHero().getNumOfDeaths() == 3) {
//			System.out.println("here");
//			startMenu();
//		}
		Timer timer = new Timer(10, listen);
		timer.start();
		

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
}
