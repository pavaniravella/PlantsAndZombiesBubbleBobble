package MainFrame;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;

import GameObject.Ammo;
import GameObject.Block;
import GameObject.GameObject;
import HeroClasses.Fruit;
import HeroClasses.Hero;
import MonsterStuff.Bullet;
import MonsterStuff.Monster;

/**
 *
 * This class is responsible for drawing the game board, interacting with other
 * classes, and updating the screen.
 *
 */
public class GameBoard extends JComponent {

	private ArrayList<Monster> monsters;
	private ArrayList<Block> blocks;
	private ArrayList<GameObject> gameObjects;
	private ArrayList<Fruit> toAddFruits;
	private int numTicks, level;
	private JFrame frame;
	private ArrayList<Ammo> ammo; // array list of the ammo
	private ArrayList<Bullet> bullets;
	private Hero ourHero;
	private static GameBoard uniqueInstance;

	public static synchronized GameBoard getBoard() {
		if (uniqueInstance == null) {
			uniqueInstance = new GameBoard(new JFrame());
		}
		return uniqueInstance;
	}

	private GameBoard(JFrame frame) {
		// make sure to add a keylistener that loads levels , add a separate class
		// add a
		this.frame = frame;
		monsters = new ArrayList<Monster>();
		blocks = new ArrayList<Block>();
		gameObjects = new ArrayList<GameObject>();
		ammo = new ArrayList<Ammo>();
		toAddFruits = new ArrayList<Fruit>();
		this.repaint();

	}

	public void updateState() {
		handleCollision();
		// fruit handling
		this.addFruit();
		Random randomNum = new Random();
		if (numTicks % 10 == 0) {
//			ourHero.update();
			for (Monster m : this.monsters) { // updates each of the monsters

				if (randomNum.nextInt() % 200 == 0) {

					m.shoot();
				}
			}
			for (GameObject g : this.gameObjects) // updates each game object
			{

				g.update();

			}
			for (Ammo a : this.ammo) {
				a.update();
			}

		}
		this.repaint();
	}

	public int getLevel() {
		return level;
	}

	public void addAmmo(Ammo a) {
		ammo.add(a);
		gameObjects.add(a);
	}

	public ArrayList<Bullet> getBullets() {
		for (Ammo a : this.ammo) {

			if (a.getClass().getSimpleName().equals("Bullet")) {
				bullets.add((Bullet) a);
			}
		}
		return bullets;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		for (GameObject b : this.getGameObjects()) {
			if (!b.shouldRemove()) {
				b.drawOn(g2);
			}
		}

		for (Block b : this.blocks) {
			b.drawOn(g2);
		}

	}

	public ArrayList<Monster> getMonsters() {
		return monsters;
	}

	public void addMonster(Monster m) {
		monsters.add(m);
	}

	public ArrayList<Block> getBlocks() {
		return blocks;
	}

	public ArrayList<GameObject> getGameObjects() {
		return this.gameObjects;
	}

	public void handleCollision() {
		for (GameObject g : this.gameObjects) {
			for (GameObject o : this.gameObjects) {
				if (!g.equals(o)) {
					g.collidesWith(o);
				}
			}

		}
		for (Block block : this.blocks) {
			gameObjects.forEach(gameObject -> gameObject.collidesWith(block));
		}
		// need to a for loop for the bullets

		gameObjects.removeIf(object -> object.shouldRemove());
		monsters.removeIf(object -> object.shouldRemove());
	}

	public JFrame getFrame() {
		return frame;
	}

	/**
	 * Called from LevelIO to set the Hero when making the level
	 * 
	 * @param givenHero
	 */
	public void setGameHero(Hero givenHero) {
		this.ourHero = givenHero;
	}

	public Hero getHero() {
		return this.ourHero;
	}

	public void markToAddFruit(Fruit fruit) {
		toAddFruits.add(fruit);
	}

	public void addFruit() {
		this.gameObjects.addAll(toAddFruits);
		toAddFruits.clear();
	}
}
