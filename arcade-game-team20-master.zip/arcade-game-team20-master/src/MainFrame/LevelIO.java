package MainFrame;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;

import com.sun.glass.events.KeyEvent;

import GameObject.Block;
import HeroClasses.Hero;
import MonsterStuff.Monster;
import MonsterStuff.ShootingMonster;

/**
 * 
 * This class scans each level file in the levels folder and creates each level to the specifications. 
 * It also changes between levels when called in the ArcadeListener and passes in the parameter of what 
 * level file to read. Within the iterations within this class, all of the GameObjects are added to 
 * their appropriate lists and the main list of gameObjects.
 * 
 * @param int levelToPlay
 * @author harmetsm
 *
 */
public class LevelIO {

	private GameBoard gameComponent;
	public int level;
	private Hero ourHero;

	public LevelIO(int levelToPlay) {
		this.gameComponent = GameBoard.getBoard();	
		this.level = levelToPlay;
		
		ourHero = new Hero("Mario", 500, 70, 0, 1);
		gameComponent.setGameHero(ourHero);
		readLevel(level);

	}
	
	public int getLevel() {
		return this.level;
	}

	public void readLevel(int levelToPlay) {
		Scanner scanner;
		try {
			scanner = new Scanner(new File("levels/level" + levelToPlay));
//			System.out.println("Level Created!");
		} catch (FileNotFoundException e) {
			System.out.println("levels/level" + levelToPlay + " not found");
			// e.printStackTrace();
			return;
		}
		int rowCounter = 0;
		int colCounter = 0;
		
		
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			colCounter = 0;
			String tempString = line;
			for (int x = 0; x < line.length(); x++) {
				char tempChar = tempString.charAt(0);

				if (tempChar == '1') {
					Block block = new Block(colCounter * 50, rowCounter * 50);
					gameComponent.getBlocks().add(block);
				}
				
				// Draws the hero
				else if (tempChar == 'H') {
					ourHero.restartHero(colCounter * 50, rowCounter * 50);
					gameComponent.getGameObjects().add(ourHero);

				}

				else if (tempChar == 'X') {
					Monster monster = new Monster("Monster" + x, colCounter * 50, 
							rowCounter * 50, 1.1,0);
					gameComponent.getGameObjects().add(monster);
					gameComponent.addMonster(monster);
				}

				else if (tempChar == 'K') {
					Monster monster = new ShootingMonster("Monster" + x, colCounter * 50,
							rowCounter * 50, 1, 0);
					gameComponent.getGameObjects().add(monster);
					gameComponent.addMonster(monster);
				}
				colCounter++;
				tempString = tempString.substring(1);
			}
			rowCounter++;

		}

		scanner.close();
		gameComponent.repaint();
	}

	public void changeLevel(int keyCode) {
		gameComponent.getBlocks().clear();
		gameComponent.getGameObjects().clear();
		gameComponent.getMonsters().clear();
		if (keyCode == KeyEvent.VK_U) {
			if (level < 3) {
				level++;
			}
		}
		
		if (keyCode == KeyEvent.VK_D) {
			if (level != 0) {
				level--;
			}
		}

		readLevel(level);
	}

}
