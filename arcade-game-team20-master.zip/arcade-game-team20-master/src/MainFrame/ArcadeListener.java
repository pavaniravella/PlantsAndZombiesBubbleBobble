package MainFrame;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import HeroClasses.Hero;

/**
 * This class is responsible for calling the KeyListener. IT takes care of all
 * the keyboard commands and calls the appropriate command from the class to
 * execute its specific functionality.
 * 
 *
 */
public class ArcadeListener implements KeyListener {

	private int level;
	private GameBoard gameBoard;
	private LevelIO current;
	private Hero hero;

	public ArcadeListener(GameBoard b, LevelIO levelIO) {
		gameBoard = b;
		hero = gameBoard.getHero();

		this.level = gameBoard.getLevel();
		current = levelIO;

	}

	@Override
	public void keyPressed(KeyEvent keyEvent) {

		// cut down 10 or so lines with this!
		if (keyEvent.getKeyCode() == KeyEvent.VK_U || keyEvent.getKeyCode() == KeyEvent.VK_D) {
			current.changeLevel(keyEvent.getKeyCode());
		}

		if (keyEvent.getKeyCode() == KeyEvent.VK_UP) {
			// up arrow
			if (!hero.isJumping()) {
				hero.yVelocity = -2;
			}
			hero.setAsJumping();
		}

		if (keyEvent.getKeyCode() == KeyEvent.VK_RIGHT) {
			// right arrow
			hero.xVelocity = 1;
		}
		if (keyEvent.getKeyCode() == KeyEvent.VK_LEFT) {
			// left arrow
			hero.xVelocity = -1;
		}

		if (keyEvent.getKeyCode() == KeyEvent.VK_SPACE) // get space
		{
			hero.shoot();
		}
		gameBoard.updateState();
	}

	@Override
	public void keyReleased(KeyEvent keyEvent) {
		if (keyEvent.getKeyCode() == KeyEvent.VK_LEFT || keyEvent.getKeyCode() == KeyEvent.VK_RIGHT) {
			hero.xVelocity = 0;
		}
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// do nothing, keep for interface needs
	}

}
